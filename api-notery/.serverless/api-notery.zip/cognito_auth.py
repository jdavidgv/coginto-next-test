
import boto3


def signup_handler(event, context):
    event['response']['autoConfirmUser'] = True
    return event


def post_signup_handler(event, context):
    print("usuario registrado, evento: {}".format(event))
    ses_client = boto3.client('ses')
    ses_client.send_email(
        Source='david.garcia@tbbc.ai',
        Destination={'ToAddresses': [
            event['request']['userAttributes']['email']]},
        Message={
            'Subject': {'Data': 'Nuevo usuario registrado'},
            'Body': {'Text': {'Data': 'Registro exitoso!'}}
        }
    )
    return event
