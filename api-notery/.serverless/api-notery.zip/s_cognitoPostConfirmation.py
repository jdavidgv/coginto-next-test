import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='dawish',
    application_name='notery-user-management-test',
    app_uid='ZHQLd6MzRn1QN2JDvD',
    org_uid='932193df-40fa-4287-88ee-400956d70993',
    deployment_uid='1e32ac46-de20-4740-a8d5-9ce1d807306e',
    service_name='api-notery',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-notery-dev-cognitoPostConfirmation', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('cognito_auth.post_signup_handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
